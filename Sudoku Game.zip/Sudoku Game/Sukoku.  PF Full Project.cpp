/////////////////////Change score=========================
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;

const int board_size = 9;
const int e_cell = 0;
int total_score = 0;

// Function prototypes
void generate_sudoku(int board[board_size][board_size]);
void print_board(int board[board_size][board_size]);
bool is_valid_move(int board[board_size][board_size], int row, int col, int num);
bool solve_sudoku(int board[board_size][board_size]);
bool board_full(int board[board_size][board_size]);
void play_game();
void show_scores();
void credits();
void instructions();

// ASCII art for Sudoku title
void print_title() {
    cout << "\033[1;33m" << R"(
  _____         _              _____      _           
 |_   _|____  _| |_ ___  _ __|_   _|   _| |__   ___  
   | |/ _ \ \/ / __/ _ \| '__|| || | | | | '_ \ / _ \ 
   | |  __/>  <| || (_) | |   | || |_| |_| | |_) | (_) |
   |_|\___/_/\_\\__\___/|_|   |_| \__, (_)_.__/ \___/ 
                                   |___/               
)" << "\033[0m" << endl;
}

int main() {
    int option = 0;
    cout << "\033[1;36mHere is Menu\033[0m" << endl;
    cout << "\033[1;35m1. Play Game\n";
    cout << "\033[1;34m2. Credits\n";
    cout << "\033[1;33m3. Instructions\n";
    cout << "\033[1;32m4. Score\n";
    cout << "\033[1;31m5. Exit\n";
    cout << "\033[1;36mEnter option: \033[0m";
    cin >> option;
    switch (option) {
        case 1: {
            srand(time(0));
            play_game();
            break;
        }
        case 2: {
            credits();
            break;
        }
        case 3: {
            instructions();
            break;
        }
        case 4: {
            show_scores();
            break;
        }
        case 5: {
            cout << "\033[1;32mYou successfully exited\033[0m" << endl;
            break;
        }
        default: {
            cout << "\033[1;32mInvalid input\033[0m" << endl;
            break;
        }
    }
    return 0;
}

// Function to generate a random Sudoku puzzle
void generate_sudoku(int board[board_size][board_size]) {
    // Start with an empty board
    for (int i = 0; i < board_size; ++i) {
        for (int j = 0; j < board_size; ++j) {
            board[i][j] = e_cell;
        }
    }

    // Solve the empty board to get a valid Sudoku solution
    solve_sudoku(board);

    // Randomly remove numbers to create a puzzle
    int num_removed = 0;
    while (num_removed < 40) {  // Adjust the difficulty level by changing the number of removed cells
        int row = rand() % board_size;
        int col = rand() % board_size;
        if (board[row][col] != e_cell) {
            board[row][col] = e_cell;
            num_removed++;
        }
    }
}

// Function to print the Sudoku board
void print_board(int board[board_size][board_size]) {
    cout << "\033[1;31m-------------------------\n";
    for (int i = 0; i < board_size; ++i) {
        for (int j = 0; j < board_size; ++j) {
            if (j % 3 == 0 && j != 0)
                cout << "| ";
            if (board[i][j] == e_cell)
                cout << ". ";
            else
                cout << board[i][j] << " ";
        }
        cout << endl;
        if ((i + 1) % 3 == 0 && i != board_size - 1)
            cout << "-------------------------\n";
    }
    cout << "\033[1;31m-------------------------\033[0m\n";
}

// Function to check if the move is valid
bool is_valid_move(int board[board_size][board_size], int row, int col, int num) {
    // Check if the number exists in the row or column
    for (int i = 0; i < board_size; ++i) {
        if (board[row][i] == num || board[i][col] == num)
            return false;
    }
    // Check if the number exists in the 3x3 subgrid
    int s_row = row - row % 3;
    int s_col = col - col % 3;
    for (int i = s_row; i < s_row + 3; ++i) {
        for (int j = s_col; j < s_col + 3; ++j) {
            if (board[i][j] == num)
                return false;
        }
    }
    return true;
}

// Function to solve the Sudoku puzzle recursively
bool solve_sudoku(int board[board_size][board_size]) {
    for (int row = 0; row < board_size; ++row) {
        for (int col = 0; col < board_size; ++col) {
            if (board[row][col] == e_cell) {
                for (int num = 1; num <= 9; ++num) {
                    if (is_valid_move(board, row, col, num)) {
                        board[row][col] = num;
                        if (solve_sudoku(board))
                            return true;
                        board[row][col] = e_cell; // Backtrack
                    }
                }
                return false; // No valid number found
            }
        }
    }
    return true; // Sudoku solved
}

// Function to check if the Sudoku board is full
bool board_full(int board[board_size][board_size]) {
    for (int i = 0; i < board_size; ++i) {
        for (int j = 0; j < board_size; ++j) {
            if (board[i][j] == e_cell)
                return false;
        }
    }
    return true;
}

// Function to play the Sudoku game
void play_game() {
    int sudoku_board[board_size][board_size];
    string name;
    cout << "\033[1;36mEnter your name: \033[0m";
    cin.ignore(); // Ignore the newline character left in the stream
    getline(cin, name);
    ofstream outFile("scores.txt", ios::app); // Open file in append mode
    outFile << name << ": ";
    generate_sudoku(sudoku_board);
    print_title(); // Print the Sudoku title
    cout << "\033[1;36mEnter numbers from 1 to 9 to fill in the Sudoku puzzle.\033[0m\n";
    cout << "\033[1;36mEnter 0 to quit.\n\033[0m";
    print_board(sudoku_board);
    while (!board_full(sudoku_board)) {
        int row, col, num;
        cout << "\033[1;36mEnter row (1-9) : \033[0m";
        cin >> row;
        cout << "\033[1;36mEnter col (1-9) : \033[0m";
        cin >> col;
        cout << "\033[1;36mEnter num (1-9) : \033[0m";
        cin >> num;
        if (row == 0 && col == 0 && num == 0) {
            cout << "\033[1;32mGame ended.\033[0m\n";
            break;
        }
        row--;
        col--;
        if (row < 0 || row >= board_size || col < 0 || col >= board_size || num < 1 || num > 9) {
            cout << "\033[1;31mInvalid input! Please enter valid row, column, and number.\033[0m\n";
            continue;
        }
        if (!is_valid_move(sudoku_board, row, col, num)) {
            cout << "\033[1;31mInvalid move! Please enter a valid number.\033[0m\n";
            continue;
        }
        // Increment score on each valid move
        total_score++;
        //Feedback given 
        sudoku_board[row][col] = num;
        cout << "\033[1;34mNumber " << num << " placed at row " << row + 1 << ", column " << col + 1 << ".\033[0m\n";
        print_board(sudoku_board);
    }
    if (board_full(sudoku_board)) {
        cout << "\033[1;32mCongratulations! You've solved the Sudoku puzzle.\033[0m\n";
        total_score += 100; // Increment score for each solved puzzle
    }
    cout << "\033[1;36mYour current score: " << total_score << "\033[0m\n";
    outFile << total_score << endl;
    outFile.close();
}

// Function to display the top 3 highest scores
void show_scores() {
    cout << "\033[1;31mTop 3 highest scores:\n\033[0m";
    ifstream inFile("scores.txt");
    if (!inFile) {
        cout << "No scores available yet!\n";
        return;
    }
    string line;
    int count = 0;
    while (getline(inFile, line) && count < 3) {
        cout << "\033[1;33m" << line << "\033[0m\n";
        count++;
    }
    inFile.close();
}

// Function to display credits
void credits() {
    cout << "\033[1;34mThis game is created by Students of FAST CFD.\n";
    cout << "Game created by Ahmad (23F-0763) and Noman (23F-0629).\033[0m\n";
}

// Function to display instructions
void instructions() {
    cout << "\033[1;33mInstructions:\n";
    cout << "1. Input numbers from 1 to 9 to fill in the Sudoku puzzle.\n";
    cout << "2. Numbers should not repeat in any 3x3 box.\n";
    cout << "3. Enter 0 at any time to quit the game.\033[0m\n";
}
